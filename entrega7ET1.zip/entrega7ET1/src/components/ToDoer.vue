<template>
  <div class="container">
    <h2 class="text-center mt-5">ToDoer Aplicacion</h2>

    <div class="d-flex">
      <input
        v-model="tarea"
        type="text"
        placeholder="Ingresar tarea"
        class="form-control"
      />
      <button @click="agregarTarea" class="btn btn-warning rounded-0">
        Ingresar
      </button>
    </div>

    <table class="table table-bordered mt-5">
      <thead>
        <tr>
          <th scope="col">Tarea</th>
          <th scope="col">Estado</th>
          <th scope="col" class="text-center">#</th>
          <th scope="col" class="text-center">#</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(tarea, index) in tareas" :key="index">
          <td>
            <span :class="{ finalizada: tarea.status === 'finalizada' }">{{
              tarea.name
            }}</span>
          </td>
          <td style="width: 120px">
            <span @click="cambiarEstado(index)" class="pointer">{{
              firstCharUpper(tarea.status)
            }}</span>
          </td>
          <td>
            <div class="text-center" @click="editarTarea(index)">
              <span class="fa fa-pendiente"></span>
            </div>
          </td>
          <td>
            <div class="text-center" @click="eliminarTarea(index)">
              <span class="fa fa-eliminar"></span>
            </div>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
export default {
  name: "HelloWorld",
  props: {
    msg: String,
  },

  data() {
    return {
      tarea: "",
      tareasEditadas: null,
      estadosDisponibles: ["por hacer", "pendiente", "terminada"],
      tareas: [
        {
          name: "Comprar lechuga",
          status: "Por hacer",
        },
        {
          name: "Comprar cerveza",
          status: "pendiente",
        },
      ],
    };
  },

  methods: {
    agregarTarea() {
      if (this.task.length === 0) return;

      if (this.tareasEditadas === null) {
        this.tareas.push({
          name: this.tarea,
          status: "por hacer",
        });
      } else {
        this.tareas[this.tareasEditadas].name = this.tarea;
        this.tareasEditadas = null;
      }
      this.tarea = "";
    },

    eliminarTarea(index) {
      this.tareas.splice(index, 1);
    },

    editarTarea(index) {
      this.tarea = this.tareas[index].name;
      this.tareasEditadas = index;
    },
    cambiarEstado(index) {
      let newIndex = this.estadosDisponibles.indexOf(this.tareas[index].status);
      if (++newIndex > 2) newIndex = 0;
      this.tareas[index].status = this.estadosDisponibles[newIndex];
    },

    firstCharUpper(str) {
      return str.charAt(0).toUpperCase() + str.slice(1);
    },
  },
};
</script>


<style scoped>
.pointer {
  cursor: pointer;
}

.finished {
  text-decoration: line-through;
}
</style>
